num1 = int(input("Type an integer you wanna convert to binary and xor: "))
num2 = int(input("Type an integer you wanna convert to binary and xor: "))
num3 = bin(num1)
num4 = bin(num2)
xor_number = bin(num1 ^ num2)
print(xor_number)
number = num1 + num2
print(bin(number))

a = int((bin(num3) ^ (xor_number)
b = int((bin(num4) ^ (xor_number)

print(int(a))
print(int(b))
 