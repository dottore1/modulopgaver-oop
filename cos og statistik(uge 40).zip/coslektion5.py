import math

sideA = (float(input(" Length of side A? ")))
sideB = (float(input(" Length of side b? ")))

hypotenuse = math.sqrt((sideA**2) + (sideB**2))
print(float(hypotenuse))


#The float is more appropiate because of the accuracy in when you square rooting an uneven number. 