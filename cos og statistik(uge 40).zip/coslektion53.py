integer = int(input("Type an integer you want to tranform til binary: "))
print(bin(integer))